# Candle AI Mobile Prototype v0.2

This is a mobile-first Progressive Web App (PWA) shell. It can be hosted as a static HTTPS website and added to an Android home screen.

## Included
- Responsive phone-first interface
- Hinglish chat UI
- Browser speech-to-text input where supported\n- Browser text-to-speech output with a deep/lower-pitch preference (exact male voice depends on installed Android voices)\n- Voice ON/OFF control
- Chat / Market / Settings tabs
- EURUSD, GBPUSD, XAUUSD watchlist placeholders
- Broker-independent settings

## Important limitations
This is a FRONT-END DEMO, not a connected AI or live trading system:
- Chat replies are canned demo responses.
- No live quotes or candle feed are connected.
- Voice input depends on browser speech recognition support and microphone permission.\n- Voice output uses device/browser text-to-speech; it is not yet a premium neural voice and may not sound consistently male across devices.\n- Replies are still canned demo responses; natural AI conversation requires a secure cloud LLM + TTS backend.
- No trade execution.
- For a real assistant, connect a secure cloud backend and an AI API. Never put API keys in browser JavaScript.

## Use on Android
1. Extract this ZIP.
2. Host the files on an HTTPS static hosting service (for example, a static site host).
3. Open the HTTPS URL in Chrome.
4. Use Chrome menu > Add to Home screen / Install app (wording may vary).

A local file:// open may show the interface but PWA install/offline features require HTTPS or localhost.

## Live data architecture
Because broker is undecided, the app is built around a provider adapter:
- Provider A: broker-supported market-data API.
- Provider B: TradingView alert webhook (event/alert driven, not a guaranteed full tick feed).
- Provider C: MT5 terminal running on a cloud Windows VPS, with a secure server-side connector.

The official MetaTrader5 Python integration communicates with a running MT5 terminal; it is not a native Android Python bridge. Keep broker credentials server-side and use read-only market data in the first release.

## Next production milestones
1. Deploy secure backend with authentication and HTTPS.
2. Add real LLM chat API on the server.
3. Add candle data provider adapter and timestamp/session normalization.
4. Implement deterministic SMC/ICT rule engine with tests.
5. Add chart uploads and image analysis.
6. Add journal, replay/backtesting and alert preferences.
7. Test demo data before any live-market use.


## Automatic session mode (v0.4)
- When the app page is visible, the interface marks the session ON.
- When the browser/app is backgrounded or the page is hidden, the interface pauses local voice playback and marks the session paused.
- Returning to the app resumes the visible session.
- This is client-side lifecycle handling only. A production cloud backend must also use authenticated session heartbeats and server-side idle timeouts to stop remote data polling reliably. Mobile browsers may delay or omit page lifecycle events when force-stopped; do not treat this UI indicator as proof that a future backend has disconnected.
- No live monitoring is active in this prototype because no market-data backend is connected.
